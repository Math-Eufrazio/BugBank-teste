package Framework.Browser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Waits {

    private static final Duration TEMPO_LIMITE = Duration.ofSeconds(30);

    private final WebDriver driver;

    public Waits (WebDriver driver){

        this.driver = driver;
    }

    private WebDriverWait criarEspera(){

        return new WebDriverWait(driver, TEMPO_LIMITE);
    }

    public WebElement esperarVisivel(By localizador){

        return criarEspera().until(ExpectedConditions.visibilityOfElementLocated(localizador));
    }

    public WebElement esperarPresente(By localizador){

        return criarEspera().until(ExpectedConditions.presenceOfElementLocated(localizador));
    }

    public WebElement esperarClicavel(By localizador){

        return criarEspera().until(ExpectedConditions.elementToBeClickable(localizador));
    }

    public boolean esperarInvisivel(By localizador){

        return criarEspera().until(ExpectedConditions.invisibilityOfElementLocated(localizador));
    }
}
