package Framework.Browser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverManager {

    private static WebDriver driver;

    private static WebDriver criarDriver(TypeBrowser tipoNavegador) {

        switch (tipoNavegador) {

            case CHROME:
                WebDriverManager.chromedriver().setup();
                ChromeOptions opcoesChrome = new ChromeOptions();
                opcoesChrome.addArguments("--start-maximized");
                opcoesChrome.addArguments("--incognito");
                driver = new ChromeDriver(opcoesChrome);
                break;

            case EDGE:
                WebDriverManager.edgedriver().setup();
                EdgeOptions opcoesEdge = new EdgeOptions();
                opcoesEdge.addArguments("--start-maximized");
                opcoesEdge.addArguments("--incognito");
                driver = new EdgeDriver(opcoesEdge);
                break;

            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;

            case HEADLESS:
                WebDriverManager.chromedriver().setup();
                ChromeOptions opcoesHeadless = new ChromeOptions();
                opcoesHeadless.addArguments("--headless");
                opcoesHeadless.addArguments("--window-size=1366,768");
                driver = new ChromeDriver(opcoesHeadless);
                break;

        }
        return driver;
    }

    public static WebDriver obterDriver(TypeBrowser tipoNavegador){

        if (driver == null){
            driver = criarDriver(tipoNavegador);
        }
        return driver;
    }

    public static void fecharDriver(){

        if (driver != null) {

            driver.quit();
            driver = null;
        }
    }
}
