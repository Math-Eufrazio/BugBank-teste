package Framework.Utils;

import net.datafaker.Faker;

import java.text.Normalizer;
import java.util.Locale;

public class FakersGeneration {

    private final Faker faker;

    public FakersGeneration (){

        faker = new Faker(Locale.forLanguageTag("pt-BR"));
    }

    public static String removerAcentos(String texto) {

        return Normalizer
                .normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }

    public String gerarPrimeiroNome(){

        return removerAcentos(faker.name().firstName());
    }

    public String gerarEmailUnico(String prefixo){

        return prefixo + System.currentTimeMillis() + "@email.com";
    }

}
