package Framework.Utils;

import io.qameta.allure.Allure;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TakeScreenshot {

    private static final Path PASTA_PRINTS = Paths.get(System.getProperty("user.dir"), "target", "prints");

    private static int contadorDePrints = 0;

    public static void capturarTela(WebDriver driver, String nome){

        byte[] bytesDoPrint = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);

        Allure.addAttachment(nome, "image/png", new ByteArrayInputStream(bytesDoPrint), "png");

        salvarPrint(nome, bytesDoPrint);
    }

    private static void salvarPrint(String nome, byte[] bytesDoPrint){

        try {

            Files.createDirectories(PASTA_PRINTS);
            contadorDePrints++;
            String nomeArquivo = String.format("%02d_%s.png", contadorDePrints, nome.replaceAll("[^a-zA-Z0-9]+", "_"));
            Files.write(PASTA_PRINTS.resolve(nomeArquivo), bytesDoPrint);

        } catch (IOException e) {

            System.out.println("Nao foi possivel salvar o print: " + nome);
        }
    }
}
