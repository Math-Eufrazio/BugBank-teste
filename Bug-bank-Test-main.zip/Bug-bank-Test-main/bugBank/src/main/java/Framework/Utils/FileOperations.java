package Framework.Utils;

import java.io.*;
import java.util.Properties;

public class FileOperations {

    private static final String PASTA_PROPERTIES =
            System.getProperty("user.dir") + File.separator + "src" + File.separator +
                    "main" + File.separator + "resources" + File.separator +
                    "Properties" + File.separator;

    public static Properties lerProperties(String nomeArquivo){

        Properties propriedades = new Properties();

        try (InputStream entrada = new FileInputStream(PASTA_PROPERTIES + nomeArquivo + ".properties")) {

            propriedades.load(entrada);
            return propriedades;

        } catch (Exception e) {

            System.out.println("Nao foi possivel carregar o arquivo de propriedades: " + nomeArquivo);
        }

        return propriedades;
    }

    public static void salvarProperty(String nomeArquivo, String chave, String valor){

        Properties propriedades = lerProperties(nomeArquivo);

        try (OutputStream saida = new FileOutputStream(PASTA_PROPERTIES + nomeArquivo + ".properties")) {

            propriedades.setProperty(chave, valor);
            propriedades.store(saida, null);

        } catch (IOException e) {

            e.printStackTrace();

        }
    }
}
