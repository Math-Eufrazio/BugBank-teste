package Framework.Utils;

import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Acoes {

    public static void preencher(WebElement elemento, String texto){

        elemento.clear();
        elemento.sendKeys(texto);
    }

    public static void clicarViaJs(WebDriver driver, WebElement elemento){

        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", elemento);
    }

    public static void clicar(WebDriver driver, WebElement elemento){

        try {
            elemento.click();
        } catch (ElementClickInterceptedException e) {
            clicarViaJs(driver, elemento);
        }
    }
}
