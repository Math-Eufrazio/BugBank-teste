package Framework.Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Textos {

    private static final Pattern PADRAO_CONTA = Pattern.compile("(\\d+)-(\\d+)");

    public static String[] extrairConta(String texto){

        Matcher resultado = PADRAO_CONTA.matcher(texto);

        if (!resultado.find()) {
            throw new IllegalArgumentException("Nao encontrei numero de conta no texto: " + texto);
        }

        return new String[]{resultado.group(1), resultado.group(2)};
    }
}
