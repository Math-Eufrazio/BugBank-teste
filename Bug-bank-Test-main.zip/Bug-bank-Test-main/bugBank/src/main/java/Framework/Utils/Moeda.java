package Framework.Utils;

import java.math.BigDecimal;

public class Moeda {

    public static BigDecimal paraNumero(String texto){

        String textoLimpo = texto.replaceAll("[^0-9,\\-]", "").replace(",", ".");
        return new BigDecimal(textoLimpo);
    }
}
