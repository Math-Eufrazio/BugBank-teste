package Framework;

import Framework.Browser.DriverManager;
import Framework.Browser.TypeBrowser;
import Framework.Utils.FileOperations;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;

public class TestBase extends DriverManager {

    private static final String URL_SITE = FileOperations.lerProperties("url").getProperty("index");

    public static WebDriver iniciarNavegador (){

        return obterDriver(TypeBrowser.CHROME);
    }

    @BeforeEach
    public void abrirSite(){

        iniciarNavegador().get(URL_SITE);
    }

    @AfterEach
    public void encerrarTeste(){

        fecharDriver();
    }

}
