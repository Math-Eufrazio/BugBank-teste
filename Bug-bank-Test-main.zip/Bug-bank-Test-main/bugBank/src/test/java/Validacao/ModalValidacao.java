package Validacao;

import Framework.Utils.TakeScreenshot;
import PageObjects.ModalPage;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

public class ModalValidacao {

    private final WebDriver driver;
    private final ModalPage modalPage;

    public ModalValidacao (WebDriver driver){

        this.driver = driver;
        modalPage = new ModalPage(this.driver);
    }

    public void validaMensagemContem(String trechoEsperado){

        try {

            String mensagemExibida = modalPage.obterTextoModal().getText();
            Assertions.assertTrue(mensagemExibida.contains(trechoEsperado),
                    "Mensagem do modal esperada com '" + trechoEsperado + "', mas veio: '" + mensagemExibida + "'");

        } finally {

            TakeScreenshot.capturarTela(driver, "Modal: " + trechoEsperado);
        }
    }
}
