package Validacao;

import Framework.Utils.Moeda;
import Framework.Utils.TakeScreenshot;
import PageObjects.ExtratoPage;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import java.math.BigDecimal;

public class ExtratoValidacao {

    private final WebDriver driver;
    private final ExtratoPage extratoPage;

    public ExtratoValidacao (WebDriver driver){

        this.driver = driver;
        extratoPage = new ExtratoPage(this.driver);
    }

    public void validaSaldoDisponivel(BigDecimal saldoEsperado){

        try {

            BigDecimal saldoExibido = Moeda.paraNumero(extratoPage.obterSaldoDisponivel().getText());
            Assertions.assertEquals(0, saldoEsperado.compareTo(saldoExibido),
                    "Saldo disponivel esperado " + saldoEsperado + ", mas o extrato mostra " + saldoExibido);

        } finally {

            TakeScreenshot.capturarTela(driver, "Extrato: saldo");
        }
    }

    public void validaLinhaTransferencia(String descricao, BigDecimal valorEsperado){

        try {

            BigDecimal valorExibido = Moeda.paraNumero(extratoPage.obterValorPorDescricao(descricao).getText()).abs();
            Assertions.assertEquals(0, valorEsperado.abs().compareTo(valorExibido),
                    "Valor da transferencia esperado " + valorEsperado + ", mas o extrato mostra " + valorExibido);

        } finally {

            TakeScreenshot.capturarTela(driver, "Extrato: transferencia");
        }
    }
}
