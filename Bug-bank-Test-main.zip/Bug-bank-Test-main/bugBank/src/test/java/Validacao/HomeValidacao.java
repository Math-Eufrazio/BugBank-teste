package Validacao;

import Framework.Utils.Moeda;
import Framework.Utils.TakeScreenshot;
import PageObjects.HomePage;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import java.math.BigDecimal;

public class HomeValidacao {

    private final WebDriver driver;
    private final HomePage homePage;

    public HomeValidacao (WebDriver driver){

        this.driver = driver;
        homePage = new HomePage(this.driver);
    }

    public void validaUsuarioLogado(String nomeEsperado){

        try {

            String saudacao = homePage.obterNomeUsuario().getText();
            Assertions.assertTrue(saudacao.contains(nomeEsperado),
                    "Home deveria cumprimentar '" + nomeEsperado + "', mas mostrou: '" + saudacao + "'");

        } finally {

            TakeScreenshot.capturarTela(driver, "Home");
        }
    }

    public void validaNumeroConta(String numeroEsperado, String digitoEsperado){

        try {

            Assertions.assertEquals(numeroEsperado + "-" + digitoEsperado, homePage.obterNumeroConta().getText().trim());

        } catch (AssertionError | RuntimeException e) {

            TakeScreenshot.capturarTela(driver, "Numero da conta");
            throw e;
        }
    }

    public void validaSaldoPositivo(){

        try {

            BigDecimal saldoExibido = Moeda.paraNumero(homePage.obterSaldo().getText());
            Assertions.assertTrue(saldoExibido.compareTo(BigDecimal.ZERO) > 0,
                    "A conta deveria ter saldo, mas o saldo e " + saldoExibido);

        } catch (AssertionError | RuntimeException e) {

            TakeScreenshot.capturarTela(driver, "Saldo da conta");
            throw e;
        }
    }
}
