package Validacao;

import Framework.Utils.TakeScreenshot;
import PageObjects.TransferenciaPage;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

public class TransferenciaValidacao {

    private final WebDriver driver;
    private final TransferenciaPage transferenciaPage;

    public TransferenciaValidacao (WebDriver driver){

        this.driver = driver;
        transferenciaPage = new TransferenciaPage(this.driver);
    }

    public void validaTelaTransferencia(){

        try {

            Assertions.assertTrue(transferenciaPage.obterTituloTela().isDisplayed());

        } finally {

            TakeScreenshot.capturarTela(driver, "Tela de transferencia");
        }
    }
}
