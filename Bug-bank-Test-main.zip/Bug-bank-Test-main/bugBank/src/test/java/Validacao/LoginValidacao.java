package Validacao;

import Framework.Utils.TakeScreenshot;
import PageObjects.LoginPage;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

public class LoginValidacao {

    private final WebDriver driver;
    private final LoginPage loginPage;

    public LoginValidacao (WebDriver driver){

        this.driver = driver;
        loginPage = new LoginPage(this.driver);
    }

    public void validaTelaLogin(){

        try {

            Assertions.assertTrue(loginPage.obterBotaoAcessar().isDisplayed());

        } finally {

            TakeScreenshot.capturarTela(driver, "Login");
        }
    }
}
