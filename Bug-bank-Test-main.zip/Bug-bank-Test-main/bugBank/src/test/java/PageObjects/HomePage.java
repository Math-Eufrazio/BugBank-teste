package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

    private static final By TEXTO_NOME_USUARIO = By.xpath("//p[@id='textName']");
    private static final By TEXTO_NUMERO_CONTA = By.xpath("//p[@id='textAccountNumber']/span");
    private static final By TEXTO_SALDO = By.xpath("//p[@id='textBalance']/span");
    private static final By BOTAO_TRANSFERENCIA = By.xpath("//a[starts-with(@id,'btn-TRANSFER')]");
    private static final By BOTAO_EXTRATO = By.xpath("//a[@id='btn-EXTRATO']");

    private final Waits esperas;

    public HomePage(WebDriver driver){

        esperas = new Waits(driver);
    }

    public WebElement obterNomeUsuario(){

        return esperas.esperarVisivel(TEXTO_NOME_USUARIO);
    }

    public WebElement obterNumeroConta(){

        return esperas.esperarVisivel(TEXTO_NUMERO_CONTA);
    }

    public WebElement obterSaldo(){

        return esperas.esperarVisivel(TEXTO_SALDO);
    }

    public WebElement obterBotaoTransferencia(){

        return esperas.esperarClicavel(BOTAO_TRANSFERENCIA);
    }

    public WebElement obterBotaoExtrato(){

        return esperas.esperarClicavel(BOTAO_EXTRATO);
    }
}
