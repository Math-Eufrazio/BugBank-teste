package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TransferenciaPage {

    private static final By TEXTO_TITULO_TELA = By.xpath("//p[contains(text(),'Realize transferência')]");
    private static final By CAMPO_NUMERO_CONTA = By.xpath("//input[@name='accountNumber']");
    private static final By CAMPO_DIGITO = By.xpath("//input[@name='digit']");
    private static final By CAMPO_VALOR = By.xpath("//input[@name='transferValue']");
    private static final By CAMPO_DESCRICAO = By.xpath("//input[@name='description']");
    private static final By BOTAO_TRANSFERIR = By.xpath("//button[text()='Transferir agora']");
    private static final By BOTAO_VOLTAR = By.xpath("//a[@id='btnBack']");

    private final Waits esperas;

    public TransferenciaPage(WebDriver driver){

        esperas = new Waits(driver);
    }

    public WebElement obterTituloTela(){

        return esperas.esperarVisivel(TEXTO_TITULO_TELA);
    }

    public WebElement obterCampoNumeroConta(){

        return esperas.esperarVisivel(CAMPO_NUMERO_CONTA);
    }

    public WebElement obterCampoDigito(){

        return esperas.esperarVisivel(CAMPO_DIGITO);
    }

    public WebElement obterCampoValor(){

        return esperas.esperarVisivel(CAMPO_VALOR);
    }

    public WebElement obterCampoDescricao(){

        return esperas.esperarVisivel(CAMPO_DESCRICAO);
    }

    public WebElement obterBotaoTransferir(){

        return esperas.esperarClicavel(BOTAO_TRANSFERIR);
    }

    public WebElement obterBotaoVoltar(){

        return esperas.esperarClicavel(BOTAO_VOLTAR);
    }
}
