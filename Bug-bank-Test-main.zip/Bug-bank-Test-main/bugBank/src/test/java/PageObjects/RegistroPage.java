package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class RegistroPage {

    private static final By CAMPO_EMAIL = By.xpath("//div[@class='card__register']//input[@name='email']");
    private static final By CAMPO_NOME = By.xpath("//div[@class='card__register']//input[@name='name']");
    private static final By CAMPO_SENHA = By.xpath("//div[@class='card__register']//input[@name='password']");
    private static final By CAMPO_CONFIRMACAO_SENHA = By.xpath("//input[@name='passwordConfirmation']");
    private static final By TOGGLE_CONTA_COM_SALDO = By.xpath("//label[@id='toggleAddBalance']");
    private static final By ESTADO_TOGGLE_CONTA_COM_SALDO = By.xpath("//label[@id='toggleAddBalance']/following-sibling::span");
    private static final By BOTAO_CADASTRAR = By.xpath("//button[text()='Cadastrar']");
    private static final By LINK_VOLTAR_LOGIN = By.xpath("//a[@id='btnBackButton']");

    private final WebDriver driver;
    private final Waits esperas;

    public RegistroPage(WebDriver driver){

        this.driver = driver;
        esperas = new Waits(this.driver);
    }

    public WebElement obterCampoEmail(){

        return esperas.esperarVisivel(CAMPO_EMAIL);
    }

    public WebElement obterCampoNome(){

        return esperas.esperarVisivel(CAMPO_NOME);
    }

    public WebElement obterCampoSenha(){

        return esperas.esperarVisivel(CAMPO_SENHA);
    }

    public WebElement obterCampoConfirmacaoSenha(){

        return esperas.esperarVisivel(CAMPO_CONFIRMACAO_SENHA);
    }

    public WebElement obterToggleContaComSaldo(){

        return esperas.esperarPresente(TOGGLE_CONTA_COM_SALDO);
    }

    public WebElement obterEstadoToggleContaComSaldo(){

        return esperas.esperarPresente(ESTADO_TOGGLE_CONTA_COM_SALDO);
    }

    public WebElement obterBotaoCadastrar(){

        return esperas.esperarClicavel(BOTAO_CADASTRAR);
    }

    public WebElement obterLinkVoltarLogin(){

        return esperas.esperarClicavel(LINK_VOLTAR_LOGIN);
    }

    public boolean registroEstaVisivel(){

        List<WebElement> camposEncontrados = driver.findElements(CAMPO_EMAIL);
        return !camposEncontrados.isEmpty() && camposEncontrados.get(0).isDisplayed();
    }
}
