package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class LoginPage {

    private static final By CAMPO_EMAIL = By.xpath("//div[@class='card__login']//input[@name='email']");
    private static final By CAMPO_SENHA = By.xpath("//div[@class='card__login']//input[@name='password']");
    private static final By BOTAO_ACESSAR = By.xpath("//div[@class='card__login']//button[text()='Acessar']");
    private static final By BOTAO_REGISTRAR = By.xpath("//div[@class='card__login']//div[@class='login__buttons']/button[@type='button']");

    private final WebDriver driver;
    private final Waits esperas;

    public LoginPage(WebDriver driver){

        this.driver = driver;
        esperas = new Waits(this.driver);
    }

    public WebElement obterCampoEmail(){

        return esperas.esperarVisivel(CAMPO_EMAIL);
    }

    public WebElement obterCampoSenha(){

        return esperas.esperarVisivel(CAMPO_SENHA);
    }

    public WebElement obterBotaoAcessar(){

        return esperas.esperarClicavel(BOTAO_ACESSAR);
    }

    public WebElement obterBotaoRegistrar(){

        return esperas.esperarClicavel(BOTAO_REGISTRAR);
    }

    public boolean loginEstaVisivel(){

        List<WebElement> camposEncontrados = driver.findElements(CAMPO_EMAIL);
        return !camposEncontrados.isEmpty() && camposEncontrados.get(0).isDisplayed();
    }
}
