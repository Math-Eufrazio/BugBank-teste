package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExtratoPage {

    private static final String DESCRICAO_SALDO_INICIAL = "Saldo adicionado ao abrir conta";

    private static final By TEXTO_SALDO_DISPONIVEL = By.xpath("//p[@id='textBalanceAvailable']");
    private static final By BOTAO_SAIR = By.xpath("//a[@id='btnExit']");

    private final Waits esperas;

    public ExtratoPage(WebDriver driver){

        esperas = new Waits(driver);
    }

    public WebElement obterSaldoDisponivel(){

        return esperas.esperarVisivel(TEXTO_SALDO_DISPONIVEL);
    }

    public WebElement obterValorPorDescricao(String descricao){

        return esperas.esperarVisivel(By.xpath(
                "//p[@id='textDescription' and text()='" + descricao + "']"
                        + "/following-sibling::p[@id='textTransferValue']"));
    }

    public WebElement obterValorSaldoInicial(){

        return obterValorPorDescricao(DESCRICAO_SALDO_INICIAL);
    }

    public WebElement obterBotaoSair(){

        return esperas.esperarClicavel(BOTAO_SAIR);
    }
}
