package PageObjects;

import Framework.Browser.Waits;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ModalPage {

    private static final By TEXTO_MODAL = By.xpath("//p[@id='modalText']");
    private static final By BOTAO_FECHAR = By.xpath("//a[@id='btnCloseModal']");

    private final Waits esperas;

    public ModalPage(WebDriver driver){

        esperas = new Waits(driver);
    }

    public WebElement obterTextoModal(){

        return esperas.esperarVisivel(TEXTO_MODAL);
    }

    public WebElement obterBotaoFechar(){

        return esperas.esperarClicavel(BOTAO_FECHAR);
    }

    public void aguardarFechamento(){

        esperas.esperarInvisivel(TEXTO_MODAL);
    }
}
