package Tasks;

import Framework.Utils.FileOperations;
import Framework.Utils.Moeda;
import PageObjects.ExtratoPage;
import PageObjects.HomePage;
import PageObjects.LoginPage;
import Validacao.ExtratoValidacao;
import org.openqa.selenium.WebDriver;

import java.math.BigDecimal;

public class ExtratoTask {

    private final HomePage homePage;
    private final ExtratoPage extratoPage;
    private final LoginPage loginPage;
    private final ExtratoValidacao extratoValidacao;

    public ExtratoTask (WebDriver driver){

        homePage = new HomePage(driver);
        extratoPage = new ExtratoPage(driver);
        loginPage = new LoginPage(driver);
        extratoValidacao = new ExtratoValidacao(driver);
    }

    public void validarExtratoOrigem(){

        abrirExtrato();
        BigDecimal valorTransferido = lerValorTransferido();
        extratoValidacao.validaSaldoDisponivel(lerSaldoInicial().subtract(valorTransferido));
        extratoValidacao.validaLinhaTransferencia(lerDescricaoTransferencia(), valorTransferido);
    }

    public void validarExtratoDestino(){

        abrirExtrato();
        BigDecimal valorRecebido = lerValorTransferido();
        extratoValidacao.validaSaldoDisponivel(lerSaldoInicial().add(valorRecebido));
        extratoValidacao.validaLinhaTransferencia(lerDescricaoTransferencia(), valorRecebido);
    }

    public void sair(){

        extratoPage.obterBotaoSair().click();
        loginPage.obterCampoEmail();
    }

    private void abrirExtrato(){

        homePage.obterBotaoExtrato().click();
        extratoPage.obterSaldoDisponivel();
    }

    private BigDecimal lerSaldoInicial(){

        return Moeda.paraNumero(extratoPage.obterValorSaldoInicial().getText());
    }

    private BigDecimal lerValorTransferido(){

        return new BigDecimal(FileOperations.lerProperties("transferencia").getProperty("valor"));
    }

    private String lerDescricaoTransferencia(){

        return FileOperations.lerProperties("transferencia").getProperty("descricao");
    }
}
