package Tasks;

import Framework.Utils.FileOperations;
import Validacao.HomeValidacao;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class HomeTask {

    private final HomeValidacao homeValidacao;

    public HomeTask (WebDriver driver){

        homeValidacao = new HomeValidacao(driver);
    }

    public void validarHome(String perfil){

        Properties dadosConta = FileOperations.lerProperties("conta");

        String nome = dadosConta.getProperty(perfil + "Nome");
        String numero = dadosConta.getProperty(perfil + "Conta");
        String digito = dadosConta.getProperty(perfil + "Digito");

        homeValidacao.validaUsuarioLogado(nome);
        homeValidacao.validaNumeroConta(numero, digito);
        homeValidacao.validaSaldoPositivo();
    }
}
