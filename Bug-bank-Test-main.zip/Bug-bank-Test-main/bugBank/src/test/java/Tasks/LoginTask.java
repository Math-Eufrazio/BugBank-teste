package Tasks;

import Framework.Utils.Acoes;
import Framework.Utils.FileOperations;
import PageObjects.LoginPage;
import PageObjects.RegistroPage;
import Validacao.LoginValidacao;
import org.openqa.selenium.WebDriver;

public class LoginTask {

    private final WebDriver driver;
    private final LoginPage loginPage;
    private final RegistroPage registroPage;
    private final LoginValidacao loginValidacao;

    public LoginTask (WebDriver driver){

        this.driver = driver;
        loginPage = new LoginPage(this.driver);
        registroPage = new RegistroPage(this.driver);
        loginValidacao = new LoginValidacao(this.driver);
    }

    public void efetuarLogin(String perfil){

        String email = FileOperations.lerProperties("conta").getProperty(perfil + "Email");
        String senha = FileOperations.lerProperties("user").getProperty(perfil + "Senha");

        if (!loginPage.loginEstaVisivel()) {
            Acoes.clicar(driver, registroPage.obterLinkVoltarLogin());
        }

        loginValidacao.validaTelaLogin();
        Acoes.preencher(loginPage.obterCampoEmail(), email);
        Acoes.preencher(loginPage.obterCampoSenha(), senha);
        Acoes.clicar(driver, loginPage.obterBotaoAcessar());
    }
}
