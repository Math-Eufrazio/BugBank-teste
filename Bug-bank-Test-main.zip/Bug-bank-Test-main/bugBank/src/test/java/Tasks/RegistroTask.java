package Tasks;

import Framework.Utils.Acoes;
import Framework.Utils.FakersGeneration;
import Framework.Utils.FileOperations;
import Framework.Utils.Textos;
import PageObjects.LoginPage;
import PageObjects.ModalPage;
import PageObjects.RegistroPage;
import Validacao.ModalValidacao;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class RegistroTask {

    private final WebDriver driver;
    private final LoginPage loginPage;
    private final RegistroPage registroPage;
    private final ModalPage modalPage;
    private final ModalValidacao modalValidacao;
    private final FakersGeneration geradorDeDados;

    private String classeToggleDesligado;

    public RegistroTask (WebDriver driver){

        this.driver = driver;
        loginPage = new LoginPage(this.driver);
        registroPage = new RegistroPage(this.driver);
        modalPage = new ModalPage(this.driver);
        modalValidacao = new ModalValidacao(this.driver);
        geradorDeDados = new FakersGeneration();
    }

    public void cadastrarConta(String perfil){

        String nome = geradorDeDados.gerarPrimeiroNome();
        String email = geradorDeDados.gerarEmailUnico(perfil);
        String senha = FileOperations.lerProperties("user").getProperty(perfil + "Senha");

        FileOperations.salvarProperty("conta", perfil + "Nome", nome);
        FileOperations.salvarProperty("conta", perfil + "Email", email);

        if (!registroPage.registroEstaVisivel()) {
            Acoes.clicar(driver, loginPage.obterBotaoRegistrar());
        }

        Acoes.preencher(registroPage.obterCampoEmail(), email);
        Acoes.preencher(registroPage.obterCampoNome(), nome);
        Acoes.preencher(registroPage.obterCampoSenha(), senha);
        Acoes.preencher(registroPage.obterCampoConfirmacaoSenha(), senha);
        garantirContaComSaldo();
        Acoes.clicar(driver, registroPage.obterBotaoCadastrar());

        modalValidacao.validaMensagemContem("foi criada com sucesso");

        String[] numeroEDigito = Textos.extrairConta(modalPage.obterTextoModal().getText());
        FileOperations.salvarProperty("conta", perfil + "Conta", numeroEDigito[0]);
        FileOperations.salvarProperty("conta", perfil + "Digito", numeroEDigito[1]);

        Acoes.clicar(driver, modalPage.obterBotaoFechar());
        modalPage.aguardarFechamento();
    }

    private void garantirContaComSaldo(){

        String classeAtualDoToggle = registroPage.obterEstadoToggleContaComSaldo().getAttribute("class");

        if (classeToggleDesligado == null) {
            classeToggleDesligado = classeAtualDoToggle;
        }

        if (!classeAtualDoToggle.equals(classeToggleDesligado)) {
            return;
        }

        WebElement toggle = registroPage.obterToggleContaComSaldo();

        try {
            toggle.click();
        } catch (WebDriverException e) {
            Acoes.clicarViaJs(driver, toggle);
        }

        if (!aguardarMudancaDoToggle()) {
            Acoes.clicarViaJs(driver, toggle);
        }

        Assertions.assertTrue(aguardarMudancaDoToggle(),
                "Nao consegui ligar o toggle 'Criar conta com saldo'");
    }

    private boolean aguardarMudancaDoToggle(){

        try {

            return new WebDriverWait(driver, Duration.ofSeconds(3)).until(
                    d -> !classeToggleDesligado.equals(registroPage.obterEstadoToggleContaComSaldo().getAttribute("class")));

        } catch (WebDriverException e) {

            return false;
        }
    }
}
