package Tasks;

import Framework.Utils.Acoes;
import Framework.Utils.FileOperations;
import PageObjects.HomePage;
import PageObjects.ModalPage;
import PageObjects.TransferenciaPage;
import Validacao.ModalValidacao;
import Validacao.TransferenciaValidacao;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class TransferenciaTask {

    private final WebDriver driver;
    private final HomePage homePage;
    private final TransferenciaPage transferenciaPage;
    private final ModalPage modalPage;
    private final TransferenciaValidacao transferenciaValidacao;
    private final ModalValidacao modalValidacao;

    public TransferenciaTask (WebDriver driver){

        this.driver = driver;
        homePage = new HomePage(this.driver);
        transferenciaPage = new TransferenciaPage(this.driver);
        modalPage = new ModalPage(this.driver);
        transferenciaValidacao = new TransferenciaValidacao(this.driver);
        modalValidacao = new ModalValidacao(this.driver);
    }

    public void transferir(){

        Properties dadosConta = FileOperations.lerProperties("conta");
        Properties dadosTransferencia = FileOperations.lerProperties("transferencia");

        homePage.obterBotaoTransferencia().click();
        transferenciaValidacao.validaTelaTransferencia();

        Acoes.preencher(transferenciaPage.obterCampoNumeroConta(), dadosConta.getProperty("destinoConta"));
        Acoes.preencher(transferenciaPage.obterCampoDigito(), dadosConta.getProperty("destinoDigito"));
        Acoes.preencher(transferenciaPage.obterCampoValor(), dadosTransferencia.getProperty("valor"));
        Acoes.preencher(transferenciaPage.obterCampoDescricao(), dadosTransferencia.getProperty("descricao"));
        Acoes.clicar(driver, transferenciaPage.obterBotaoTransferir());

        modalValidacao.validaMensagemContem("realizada com sucesso");
        Acoes.clicar(driver, modalPage.obterBotaoFechar());
        modalPage.aguardarFechamento();

        transferenciaPage.obterBotaoVoltar().click();
        homePage.obterNomeUsuario();
    }
}
