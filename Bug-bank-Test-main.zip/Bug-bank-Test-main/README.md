# BugBank - Automação de Testes Web

Esse é o meu trabalho da prova de teste. Eu automatizei, com Selenium e Java, uma transferência entre duas contas no [BugBank](https://bugbank.netlify.app/), um site de banco feito só pra gente treinar teste.

## O que o teste faz

1. Abre o site do BugBank
2. Cadastra duas contas com saldo: uma de **origem** e uma de **destino**
3. Faz login na origem e transfere um valor para a conta de destino
4. Abre o extrato da origem e confere se o saldo ficou certo (saldo inicial menos o valor transferido)
5. Sai, faz login na conta de destino e confere no extrato se o valor chegou (saldo inicial mais o valor recebido)

Os nomes, e-mails e números das contas mudam a cada execução, então dá pra rodar quantas vezes quiser sem dar conflito.

## Tecnologias

Java 27, Maven, Selenium 4, JUnit, Datafaker (dados falsos) e Allure (relatório).

## Como o projeto está organizado

```
src/main/java/Framework     driver, esperas, TestBase e utilitários
src/main/resources          properties (url, senhas, dados da transferência, contas geradas)
src/test/java/PageObjects   os elementos (XPath) de cada tela
src/test/java/Tasks         o que o usuário faz em cada tela
src/test/java/Validacao     as verificações e os prints (Allure)
src/test/java/TestCases     o cenário de teste
docs/                       mapeamento dos elementos do site
```

Separei assim pra cada classe ter uma função só: a **Page** só sabe onde estão os elementos, a **Task** sabe o que fazer com eles, a **Validacao** confere se deu certo e o **TestCase** só conta a história do teste.

## O que precisa ter instalado

- **JDK 27** (o `pom.xml` compila com a versão 27)
- **Maven 3.9 ou mais novo**
- **Google Chrome** (o WebDriverManager baixa o driver sozinho)
- Internet, porque o teste acessa o site de verdade

### Configurando o JAVA_HOME

O Maven usa o Java que estiver no `JAVA_HOME`. Se não tiver nada lá, ele pega o `java` do Path, que pode ser de outra versão. Aí o build quebra com:

```
Fatal error compiling: error: invalid target release: 27
```

No Windows, rode uma vez (troque pelo caminho do seu JDK 27):

```
setx JAVA_HOME "C:\Users\SEU_USUARIO\.jdks\openjdk-27.0.1.0.3"
```

Ou pela interface: **Editar as variáveis de ambiente do sistema → Variáveis de Ambiente → Novo**, com o nome `JAVA_HOME`.

Depois **feche e abra o terminal de novo**, porque o `setx` não vale pro terminal que já estava aberto. Pra conferir:

```
mvn -v
```

Tem que aparecer a versão 27 do Java. Se aparecer outra, o terminal ainda não está enxergando o `JAVA_HOME`. Pode checar com `echo %JAVA_HOME%` (cmd) ou `$env:JAVA_HOME` (PowerShell).

> O `java -version` pode continuar mostrando outra versão e tudo bem. O Maven segue o `JAVA_HOME`, não o Path.

### Se você tiver outra versão do Java

Dá pra usar outra versão, só precisa ajustar umas coisas. Exemplo com o Java 21:

1. No `pom.xml`, trocar o 27 pelo 21 (nas tags `source` e `target`)
2. Apontar o `JAVA_HOME` pro JDK 21 e abrir um terminal novo
3. Rodar `mvn clean test` e ver se não deu erro de compilação
4. No IntelliJ, ajustar o SDK e o *Language level* em File → Project Structure

O Selenium 4 precisa de no mínimo o Java 11.

## Como rodar

Dentro da pasta `bugBank` (onde fica o `pom.xml`):

```
mvn clean test
```

Não mexa no navegador enquanto o teste está rodando. Se tudo der certo, no final aparece:

```
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

O resultado também fica em `target/surefire-reports/`.

Pelo IntelliJ também funciona: com o SDK em openjdk-27, é só rodar pela aba **Maven → Lifecycle → test** ou clicar no ▶ da classe `TransferenciaEntreContasTest`.

## Evidências (prints)

Cada validação tira um print da tela. Depois do `mvn clean test` eles ficam em `target/prints/`, numerados na ordem do fluxo:

```
01_Modal_foi_criada_com_sucesso.png    cadastro da conta de origem
02_Modal_foi_criada_com_sucesso.png    cadastro da conta de destino
03_Login.png                           login da origem
04_Home.png                            home da origem (nome, conta e saldo)
05_Tela_de_transferencia.png
06_Modal_realizada_com_sucesso.png     transferência concluída
07_Extrato_saldo.png                   extrato da origem (saldo debitado)
08_Extrato_transferencia.png           extrato da origem (linha "Transferência enviada")
09_Login.png                           login do destino
10_Home.png                            home do destino
11_Extrato_saldo.png                   extrato do destino (saldo creditado)
12_Extrato_transferencia.png           extrato do destino (linha "Transferência recebida")
```

Se o teste falhar, o print do momento do erro também é salvo, com o nome `ERRO`. A pasta é apagada a cada `mvn clean`.

## Relatório Allure

Depois de rodar o `mvn clean test`:

```
mvn allure:serve
```

O relatório abre no navegador, com os prints de cada etapa. Se o teste falhar, o print do erro aparece lá também.

## Dados do teste

- Valor e descrição da transferência: `src/main/resources/Properties/transferencia.properties`
- Senhas das contas: `src/main/resources/Properties/user.properties`
- Dados das contas criadas (nome, e-mail, número e dígito): o teste grava a cada execução em `src/main/resources/Properties/conta.properties`

## Problemas que podem aparecer

| Erro | Por quê | O que fazer |
|---|---|---|
| `invalid target release: 27` | O Maven está usando um Java mais antigo | Configurar o `JAVA_HOME` com o JDK 27 e abrir um terminal novo |
| `'mvn' não é reconhecido...` | Maven fora do Path | Adicionar a pasta `bin` do Maven no Path |
| `ElementClickInterceptedException` | Algum elemento do BugBank ficou por cima do botão | Já está tratado no `Acoes.clicar()`, que clica via JavaScript |
| `SessionNotCreatedException` | Chrome desatualizado ou não instalado | Atualizar ou instalar o Google Chrome |
